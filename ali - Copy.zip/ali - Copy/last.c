/*      ali.sh      */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

int n,m;//n = satr, m = soton

char list[100][100]={'\0'};

struct adres
{
	int i;
	int j;
};

struct adres setare[1000000];

int t=0;//teadad setareha

void open (){
	FILE *ptf = fopen("testcase01.txt","r");
	int i = 0,j = 0;
	char w;
	fscanf(ptf,"%c",&w);
	while(1){
		char a[10];
		while (1){
			fscanf(ptf,"%s",a);
			if (j==0) list[i][j]=a[4];
			else list[i][j]=a[3];
			j++;
			if (a[7]=='}') break;
		}
		if (a[8]=='}') break;
		i++;
		j=0;
	}
	fclose(ptf);
}//in marbot be khondan avalie ast

void setereha(){
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (list[i][j]=='0')
			{
				setare[t].i=i;
				setare[t].j=j;
				t++;
			}
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (list[i][j]=='*')
			{
				setare[t].i=i;
				setare[t].j=j;
				t++;
			}
		}
	}
}//peyda kardan makan setareha

void matrisyab(int x,int y,int rah[]){
	int a1=0,a2=0,a3=0,a4=0;
	if (rah[x*n+y+1]==-1) a1=1;
	if (rah[x*n+y-1]==-1) a2=1;
	if (rah[(x+1)*n+y]==-1) a3=1;
	if (rah[(x-1)*n+y]==-1) a4=1;
	if (y<m-1&&list[x][y+1]=='#') rah[x*n+y+1]=0;
	if (y<m-1&&rah[x*n+y+1]==-1) rah[x*n+y+1]=rah[x*n+y]+1;
	if (y>0&&list[x][y-1]=='#') rah[x*n+y-1]=0;
	if (y>0&&rah[x*n+y-1]==-1) rah[x*n+y-1]=rah[x*n+y]+1;
	if (x<n-1&&list[x+1][y]=='#') rah[(x+1)*n+y]=0;
	if (x<n-1&&rah[(x+1)*n+y]==-1) rah[(x+1)*n+y]=rah[x*n+y]+1;
	if (x>0&&list[x-1][y]=='#') rah[(x-1)*n+y]=0;
	if (x>0&&rah[(x-1)*n+y]==-1) rah[(x-1)*n+y]=rah[x*n+y]+1;
	if (y<m-1&&a1==1) matrisyab(x,y+1,rah);
	if (y>0&&a2==1) matrisyab(x,y-1,rah);
	if (x<n-1&&a3==1) matrisyab(x+1,y,rah);
	if (x>0&&a4==1) matrisyab(x-1,y,rah);
}

int rahyab(struct adres key[],int i1,int j1,int i2,int j2){
	int rah[n*m];
	for (int jjj=0;jjj<m*n;jjj++) rah[jjj]=-1;
	int x=j2+n*i2;
	rah[x]=0;
	matrisyab(i2,j2,rah);
	masiryab(key,rah,i1,j1,i2,j2);
	return rah[j1+n*i1];
}//peyda kardan rah baine 2 makan

void masiryab(struct adres key[],int rah[],int i1,int j1,int i2,int j2){
	int x,y,z;
	x=i2;
	y=j2;
	z=x*n+y;
	key[rah[z]].i=x;
	key[rah[z]].j=y;
	if (x==i1&&y==j1) return;
	if (rah[z]==rah[z+1]-1) masiryab(key,rah,i1,j1,i2,j2+1);  
	if (rah[z]==rah[z-1]-1) masiryab(key,rah,i1,j1,i2,j2-1);
	if (rah[z]==rah[z+n]-1) masiryab(key,rah,i1,j1,i2+1,j2);
	if (rah[z]==rah[z-n]-1) masiryab(key,rah,i1,j1,i2-1,j2);
}

void printlahzeie(struct adres key[],int n,int i1,int j1,int i2,int j2){
	int x,y;
	x=i1;
	y=j1;
	for (int i=0;i<n;i++){
		printf("%s\n",list[i]);
	}
	if (x==i2&&y==j2) return;
	list[i1][j1]='1';
	list[key[0].i][key[0].j]='0';
	n--;
	i1=key[0].i;
	j1=key[0].j;
	for (int i = 1; i < n+1; i++){
		key[i-1].i=key[i].i;
		key[i-1].j=key[i].j;
	}
	fflush(stdout);
	sleep(1);
	printlahzeie(key,n,i1,j1,i2,j2);
}

int main(){
	open();
	for (int i = 0; i < 1000; i++)
	{
		if (list[i][0]=='\0') {
			n=i;
			break;
		}
	}
	for (int i = 0; i < 1000; i++)
	{
		if (list[0][i]=='\0') {
			m=i;
			break;
		}
	}
	setereha();
	for (int i = 0; i < t-1; i++)
	{
		struct adres key[10000];
		int n;
		n=rahyab(key,setare[i].i,setare[i].j,setare[i+1].i,setare[i+1].j);
		printlahzeie(key,n,setare[i].i,setare[i].j,setare[i+1].i,setare[i+1].j);
	}	 
//	printf("%s\n%s\n%s\n%s\n %d\n%d",list[0],list[1],list[2],list[3],m,n);
//	for (int i = 0; i < t; i++)
//	{
//		printf("\n%d    %d",setare[i].i,setare[i].j);
//	}
}
