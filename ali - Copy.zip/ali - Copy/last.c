/*      ali.sh      */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

int n,m;//n = satr, m = soton

char list[100][100]={'\0'};

struct adres
{
	int i;
	int j;
};

struct adres setare[1000000];

int t=0;//teadad setareha

void open (){
	FILE *ptf = fopen("testcase01.txt","r");
	int i = 0,j = 0;
	char w;
	fscanf(ptf,"%c",&w);
	while(1){
		char a[10];
		while (1){
			fscanf(ptf,"%s",a);
			if (j==0) list[i][j]=a[4];
			else list[i][j]=a[3];
			j++;
			if (a[7]=='}') break;
		}
		if (a[8]=='}') break;
		i++;
		j=0;
	}
	fclose(ptf);
}//in marbot be khondan avalie ast

void setereha(){
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (list[i][j]=='*')
			{
				setare[t].i=i;
				setare[t].j=j;
				t++;
			}
		}
	}
}//peyda kardan makan setareha

void matrisyab(int x,int y,int rah[]){
	int a1=0,a2=0,a3=0,a4=0;
	if (rah[x*n+y+1]==-1) a1=1;
	if (rah[x*n+y-1]==-1) a2=1;
	if (rah[(x+1)*n+y]==-1) a3=1;
	if (rah[(x-1)*n+y]==-1) a4=1;
	if (y<m-1&&list[x][y+1]=='#') rah[x*n+y+1]=0;
	if (y<m-1&&rah[x*n+y+1]==-1) rah[x*n+y+1]=rah[x*n+y]+1;
	if (y>0&&list[x][y-1]=='#') rah[x*n+y-1]=0;
	if (y>0&&rah[x*n+y-1]==-1) rah[x*n+y-1]=rah[x*n+y]+1;
	if (x<n-1&&list[x+1][y]=='#') rah[(x+1)*n+y]=0;
	if (x<n-1&&rah[(x+1)*n+y]==-1) rah[(x+1)*n+y]=rah[x*n+y]+1;
	if (x>0&&list[x-1][y]=='#') rah[(x-1)*n+y]=0;
	if (x>0&&rah[(x-1)*n+y]==-1) rah[(x-1)*n+y]=rah[x*n+y]+1;
	if (y<m-1&&a1==1) matrisyab(x,y+1,rah);
	if (y>0&&a2==1) matrisyab(x,y-1,rah);
	if (x<n-1&&a3==1) matrisyab(x+1,y,rah);
	if (x>0&&a4==1) matrisyab(x-1,y,rah);
}

void rahyab(struct adres key,int i1,int j1,int i2,int j2){
	int rah[n*m];
	for (int jjj=0;jjj<m*n;jjj++) rah[jjj]=-1;
	int x=j1+n*i1;
	rah[x]=0;
	matrisyab(i1,j1,rah);
	 // tarif tabee baray peyda kardan uzv haye baine masir
}//peyda kardan rah baine 2 makan

int main(){
	open();
	for (int i = 0; i < 1000; i++)
	{
		if (list[i][0]=='\0') {
			n=i;
			break;
		}
	}
	for (int i = 0; i < 1000; i++)
	{
		if (list[0][i]=='\0') {
			m=i;
			break;
		}
	}
	setereha();
	printf("%s\n%s\n%s\n%s\n %d\n%d",list[0],list[1],list[2],list[3],m,n);
	for (int i = 0; i < t; i++)
	{
		printf("\n%d    %d",setare[i].i,setare[i].j);
	}
}